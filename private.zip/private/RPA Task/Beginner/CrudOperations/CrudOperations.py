import mysql.connector as mc

db = mc.connect(host="localhost", user="root", passwd="admin", database="school")
cursor = db.cursor()

boolRunMenu = True

while boolRunMenu:
    opt = input("""
    Choose an option:
1	Add a student
2	View students
3	Update a student
4	Delete a student
5	Exit the program
    """
)
    if opt == "1":
#    Add a student
        name = input("Enter student name: ")
        age = int(input("Enter student age: "))
        grade = input("Enter student grade: ")
        try:
            cursor.execute(f"INSERT INTO student (name,age,grade) VALUES ('{name}',{age},'{grade}')")
            db.commit()
            print(f"Student {name} has been added to database.")
        except:
            db.rollback()
            print("There was an error while inserting data")

    elif opt == "2":
#         View student by Id or all students
        choice = int(input("""
            1. View All Students
            2. View Student by ID
        """))
        if choice == 1:
            try:
                cursor.execute(f"SELECT * FROM student")
                result = cursor.fetchall()
                print("------------------------Students-------------------------")
                for row in result:
                    print(f"Student ID: {row[0]} | Name: {row[1]} | Age: {row[2]} | Grade: {row[3]}")
            except Exception as e:
                print(f"There was an error while retrieving data : ", e)
        elif choice == 2:
            try:
                id = int(input("Enter student ID: "))
                cursor.execute(f"SELECT * FROM student WHERE id={id}")
                result = cursor.fetchall()
                for row in result:
                    print(f"Student ID: {row[0]} | Name: {row[1]} | Age: {row[2]} | Grade: {row[3]}")
            except Exception as e:
                print("There was an error while retrieving data : ", e)

    elif opt == "3":
        # Update student by ID
        id = int(input("Enter student ID: "))
        choice = int(input("""
        1. Update student name
        2. Update student age
        3. Update student grade
        """))

        if choice == 1:
            name = input("Enter updated student name: ")
            try:
                cursor.execute(f"UPDATE student SET name='{name}' WHERE id={id}")
                db.commit()
                print(f"Student name has been updated to database.")
            except Exception as e:
                db.rollback()
                print("There was an error while updating data : ", e)
        elif choice == 2:
            age = int(input("Enter updated student age: "))
            try:
                cursor.execute(f"UPDATE student SET age={age} WHERE id={id}")
                db.commit()
                print(f"Student age has been updated to database.")
            except Exception as e:
                db.rollback()
                print("There was an error while updating data : ", e)

        elif choice == 3:
            grade = input("Enter updated student grade: ")
            try:
                cursor.execute(f"UPDATE student SET grade='{grade}' WHERE id={id}")
                db.commit()
                print(f"Student grade has been updated to database.")
            except Exception as e:
                db.rollback()
                print("There was an error while updating data : ", e)

    elif opt == "4":
        # Delete a student
        id = input("Enter student ID: ")
        try:
            cursor.execute(f"DELETE FROM student WHERE id={id}")
            db.commit()
            print(f"Student has been deleted from database.")
        except Exception as e:
            db.rollback()
            print("There was an error while deleting data : ", e)
    elif opt == "5":
        print("Thank you for using this program!")
        boolRunMenu = False
    else:
        print("Invalid Choice")
