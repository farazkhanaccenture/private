import sys
from selenium import webdriver
from selenium.common import NoSuchElementException, TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support.select import Select

from emailService import get_outlook_otp, send_outlook_email

chrome_options = Options()
chrome_options.add_experimental_option("detach", True)
chrome_options.add_argument("--start-fullscreen")

browser = webdriver.Chrome(options=chrome_options)
browser.fullscreen_window()


try:
    browser.get("https://poultryregistration.defra.gov.uk/?handler=Next")

    time.sleep(2)

    # Step 1: Email Registration
    email_input = browser.find_element(By.ID, "RegistrationEmail")
    email_input.send_keys("faraz.g.khan@accenture.com")
    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(20)

    # Step 2: OTP Confirmation
    try:
        start_time = time.time()
        timeout = 60
        otp = None

        while time.time() - start_time < timeout:
            otp = get_outlook_otp()
            if otp:
                print("Extracted OTP: ",otp)
                break
            time.sleep(10)

        # otp = None #for testing
        if not otp:
            raise TimeoutException("OTP timed out!")

        verification_input = browser.find_element(By.ID, "VerificationCode")
        verification_input.send_keys(otp)
        save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
        save_button.click()
        time.sleep(2)
    except Exception as e:
        browser.save_screenshot(
            "emailverificationerror.png"
        )
        send_outlook_email("Email verification Service failed !", f"There was an error while verifying email: \n{e}", "faraz.g.khan@accenture.com", None, [r"C:\Users\faraz.g.khan\PycharmProjects\WebAutomation\emailverificationerror.png"])
        sys.exit(1)

    # Step 3: Are you the poultry keeper?
    radio_button = browser.find_element(By.ID, "IsKeeper")
    radio_button.click()
    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 4: Are you the owner of the birds?
    radio_button = browser.find_element(By.ID, "IsOwner")
    radio_button.click()
    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 5: Tell us about yourself
    select = Select(browser.find_element(By.CLASS_NAME, "govuk-select"))
    select.select_by_visible_text("Mr")

    forename_input = browser.find_element(By.ID, "Forename")
    forename_input.send_keys("Faraz")

    surname_input = browser.find_element(By.ID, "Surname")
    surname_input.send_keys("Khan")

    farmer_radio = browser.find_element(By.ID, "OccupierDescription")
    farmer_radio.click()

    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 6: What is your address?
    try:
        address_input = browser.find_element(By.ID, "address-postcode")
        address_input.send_keys("WA4 1AB")


        find_address_button = browser.find_element(By.ID, "Findpostcode")
        find_address_button.click()

        time.sleep(5)

        select = Select(browser.find_element(By.ID, "pcResultList"))
        select.select_by_visible_text("71, KNUTSFORD ROAD, WARRINGTON, WA4 1AB")

        save_button = browser.find_element(By.CSS_SELECTOR, "#wizardForm > input.govuk-button")
        save_button.click()
        time.sleep(2)
    except Exception as e:
        browser.save_screenshot(
            "addressserviceerror.png"
        )
        send_outlook_email("Address Service failed !", f"There was an error while adding address: \n{e}",
                           "faraz.g.khan@accenture.com", None,
                           [r"C:\Users\faraz.g.khan\PycharmProjects\WebAutomation\addressserviceerror.png"])
        sys.exit(1)

    # Step 7: Contact detail
    phone_input = browser.find_element(By.ID, "MobileNumber")
    phone_input.send_keys("+919711882741")

    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 8: Where are the birds kept?
    home_address_checkbox = browser.find_element(By.ID, "AtHome")
    home_address_checkbox.click()

    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 9: Birds location details at home address
    try:
        unable_to_use_map_checkbox = browser.find_element(By.ID, "cannotUseMap")
        unable_to_use_map_checkbox.click()

        is_map_working = browser.find_element(By.CSS_SELECTOR, "#map > div.ol-viewport > div.ol-unselectable.ol-layers > div > canvas")
        if not is_map_working:
            raise NoSuchElementException("Map Service is not working")

        save_button = browser.find_element(By.CSS_SELECTOR, "#wizardForm > input.govuk-button")
        save_button.click()
        time.sleep(2)
    except Exception as e:
        browser.save_screenshot(
            "mapserviceerror.png"
        )
        send_outlook_email("Map Service failed !", f"There was an error while loading map: \n{e}",
                           "faraz.g.khan@accenture.com", None,
                           [r"C:\Users\faraz.g.khan\PycharmProjects\WebAutomation\mapserviceerror.png"])
        sys.exit(1)

    # Step 10: What types of birds do you keep at 71 KNUTSFORD ROAD?
    list_of_birds = ["Chicken"]

    for bird in list_of_birds:
        bird_type_checkbox = browser.find_element(By.ID, bird)
        bird_type_checkbox.click()

    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 11: Tell us about your chickens kept at 71 KNUTSFORD ROAD
    reason_chicken_kept_selector = Select(browser.find_element(By.ID, "BirdDetail.KeptForReason"))
    reason_chicken_kept_selector.select_by_visible_text("Meat")

    time.sleep(2)
    purpose_chicken_kept_selector = Select(browser.find_element(By.ID, "BirdDetail.KeptForPurpose"))
    purpose_chicken_kept_selector.select_by_visible_text("Reared for Meat")

    save_button = browser.find_element(By.CLASS_NAME, "govuk-button")
    save_button.click()
    time.sleep(2)

    # Step 12: Form Confirmation
    browser.save_screenshot(
        "formconfirmation.png"
    )
    send_outlook_email("Form Confirmation", f"All Services are working accordingly, without any error",
                       "faraz.g.khan@accenture.com", None,
                       [r"C:\Users\faraz.g.khan\PycharmProjects\WebAutomation\formconfirmation.png"])


except Exception as e:
    browser.save_screenshot(
        "miscerror.png"
    )
    send_outlook_email("A Misc Error Occurred", f"There was an error while running the script: \n{e}",
                       "faraz.g.khan@accenture.com", None,
                       [r"C:\Users\faraz.g.khan\PycharmProjects\WebAutomation\miscerror.png"])

