import re
import win32com.client
from datetime import datetime, timedelta

def extract_otp(email_content):
    """
        Extracts the OTP (One Time Password) from the provided email content.

        The method looks for a pattern "Your confirmation code is:" followed by an alphanumeric OTP.

        :param email_content: The text content of the email as a string.
        :return: The extracted OTP as a string if found, otherwise None.
        """

    pattern = r"Your confirmation code is:\s*([A-Z0-9]+)"
    match = re.search(pattern, email_content)
    return match.group(1) if match else None

def get_outlook_otp():
    """
        Retrieves the most recent OTP from the Outlook inbox.

        This function searches for emails received in the last 30 minutes
        with a specific subject and body pattern related to the Poultry Registration Service.
        If such an email is found, the OTP is extracted and returned.

        :return: The OTP as a string if found; otherwise, None.
        """

    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.GetDefaultFolder(6)

    now = datetime.now().astimezone()
    thirty_minutes_ago = now - timedelta(minutes=30)

    messages = inbox.Items
    messages.Sort("[ReceivedTime]", True)

    for message in messages:
        try:
            received_time = message.ReceivedTime
            if received_time.tzinfo is None:
                received_time = received_time.replace(tzinfo=now.tzinfo)

            if received_time < thirty_minutes_ago:
                break  

            subject_match = "[External] Confirm your email address – Poultry Registration Service" in message.Subject
            body_match_1 = "Department for Environment, Food & Rural Affairs" in message.Body
            body_match_2 = "Your confirmation code is:" in message.Body

            if subject_match and body_match_1 and body_match_2:
                otp = extract_otp(message.Body)
                if otp:
                    return otp

        except Exception as e:
            print(f"Error reading email: {e}")
            continue

    return None

def send_outlook_email(subject, body, to_recipients, cc_recipients=None, attachments=None):
    """
    Sends an email via Outlook.

    :param subject: Subject of the email.
    :param body: Body content of the email.
    :param to_recipients: List of email addresses to send to.
    :param cc_recipients: (Optional) List of CC email addresses.
    :param attachments: (Optional) List of file paths to attach.
    """
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)

        mail.Subject = subject
        mail.Body = body

        if isinstance(to_recipients, list):
            mail.To = "; ".join(to_recipients)
        else:
            mail.To = to_recipients

        if cc_recipients:
            if isinstance(cc_recipients, list):
                mail.CC = "; ".join(cc_recipients)
            else:
                mail.CC = cc_recipients

        if attachments:
            for file_path in attachments:
                mail.Attachments.Add(file_path)

        mail.Send()
        print("Email sent successfully!")

    except Exception as e:
        print(f"Error while sending email: {e}")

