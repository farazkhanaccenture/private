# Flask Item API

This is a simple Flask application that provides a RESTful API for managing items in a database. It uses SQLAlchemy with an SQLite backend to store item information, which includes a name and a price.

## Features
- **GET /items** – Retrieve a list of all items.
- **GET /items/<id>** – Retrieve a single item by ID.
- **POST /items** – Create a new item.
- **PUT /items/<id>** – Update an existing item by ID.
- **DELETE /items/<id>** – Delete an item by ID.

## Prerequisites

Before running the project, make sure you have the following installed:
- Python 3.x
- `pip` (Python package installer)

### Optional (for Virtual Environment):
- `venv` or `virtualenv` (Recommended for managing dependencies in isolated environments)

## Setup Instructions

#### 1. Clone the repository (or simply create a new directory if you prefer to start fresh):

   ```bash
   git clone <repository-url>
   cd <repository-directory>
````

#### 2. (Optional) Create a virtual environment:

   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
   ```

#### 3. Install the required dependencies:

   ```bash
   pip install -r requirements.txt
   ```

#### 4. Initialize the SQLite database:

   The app will automatically create the SQLite database (`items.db`) when the first request is made, so there is no need to manually create it.

#### 5. Run the Flask application:

   ```bash
   python app.py
   ```

   By default, the Flask app will run on `http://127.0.0.1:5000`.

## API Usage

### 1. Get All Items (GET /items)

Retrieve all items in the database.

**Request:**

```http
GET /items
```

**Response:**

```json
[
  {
    "id": 1,
    "name": "Item Name",
    "price": 12.99
  },
  {
    "id": 2,
    "name": "Another Item",
    "price": 19.99
  }
]
```

### 2. Get Single Item by ID (GET /items/<id>)

Retrieve a specific item by its ID.

**Request:**

```http
GET /items/1
```

**Response:**

```json
{
  "id": 1,
  "name": "Item Name",
  "price": 12.99
}
```

If the item is not found:

```json
{
  "error": "Item not found"
}
```

### 3. Create New Item (POST /items)

Create a new item by providing the item name and price.

**Request:**

```http
POST /items
Content-Type: application/json
```

**Request Body:**

```json
{
  "name": "New Item",
  "price": 25.00
}
```

**Response:**

```json
{
  "id": 3,
  "name": "New Item",
  "price": 25.00
}
```

If the name or price is missing:

```json
{
  "error": "Name/Price is required"
}
```

### 4. Update Item by ID (PUT /items/<id>)

Update an existing item by its ID. You must provide the updated `name` and/or `price`.

**Request:**

```http
PUT /items/1
Content-Type: application/json
```

**Request Body:**

```json
{
  "name": "Updated Item",
  "price": 29.99
}
```

**Response:**

```json
{
  "id": 1,
  "name": "Updated Item",
  "price": 29.99
}
```

If the item does not exist:

```json
{
  "error": "Item not found"
}
```

If the name or price is missing:

```json
{
  "error": "Name/Price is required"
}
```

### 5. Delete Item by ID (DELETE /items/<id>)

Delete an item by its ID.

**Request:**

```http
DELETE /items/1
```

**Response:**

```json
{
  "message": "Item deleted"
}
```

If the item does not exist:

```json
{
  "error": "Item not found"
}
```

## Error Handling

The API returns standardized error responses for various error conditions:

* **400 Bad Request**: Missing or invalid data (e.g., missing `name` or `price`).
* **404 Not Found**: Item not found when attempting to retrieve, update, or delete an item.

## Development Tips

* To reset the database, you can delete `items.db` and restart the application.
* For production, consider switching from SQLite to a more robust database (e.g., PostgreSQL, MySQL) and configure appropriate database credentials.

## Dependencies

The application requires the following Python packages:

* Flask
* Flask-SQLAlchemy

These can be installed by running:

```bash
pip install flask flask_sqlalchemy
```
