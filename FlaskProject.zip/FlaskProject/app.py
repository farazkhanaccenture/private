from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///items.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Item(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'price': self.price}


# GET /items – Retrieve all items
#
# GET /items/<id> – Retrieve a single item by ID
#
# POST /items – Create a new item
#
# PUT /items/<id> – Update an existing item
#
# DELETE /items/<id> – Delete an item



@app.route("/items", methods=['GET', 'POST'])
def fetchall_or_create_items():
    if request.method == 'GET':
        items = Item.query.all()
        return jsonify([item.to_dict() for item in items])
    elif request.method == 'POST':
        data = request.get_json()
        if not data or 'name' not in data or 'price' not in data:
            return jsonify({'error': 'Name/Price is required'}), 400

        new_item = Item(name=data['name'], price=data['price'])
        db.session.add(new_item)
        db.session.commit()
        return jsonify(new_item.to_dict()), 201
    return None


@app.route("/items/<int:id>", methods=['GET', 'PUT', 'DELETE'])
def get_update_or_delete_itembyid(id):
    if request.method == 'GET':
        item = Item.query.get(id)
        if item:
            return jsonify(item.to_dict())
        return jsonify({'error': 'Item not found'}), 404

    elif request.method == 'PUT':
        data = request.get_json()
        item = Item.query.get(id)

        if not item:
            return jsonify({'error': 'Item not found'}), 404

        if not data or 'name' not in data or 'price' not in data:
            return jsonify({'error': 'Name/Price is required'}), 400

        if data['name']:
            item.name = data['name']
        if data['price']:
            item.price = data['price']
        db.session.commit()
        return jsonify(item.to_dict())
    elif request.method == 'DELETE':
        item = Item.query.get(id)

        if not item:
            return jsonify({'error': 'Item not found'}), 404

        db.session.delete(item)
        db.session.commit()
        return jsonify({'message': 'Item deleted'})
    return None


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
